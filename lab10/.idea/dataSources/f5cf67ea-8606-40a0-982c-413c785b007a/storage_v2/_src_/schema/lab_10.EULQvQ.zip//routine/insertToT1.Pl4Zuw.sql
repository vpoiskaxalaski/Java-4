create
    definer = root@localhost procedure insertToT1(IN var1 int, IN varr2 varchar(15))
begin
    insert into t1 values(var1, varr2); 
end;

